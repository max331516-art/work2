# handlers/webapp.py
from aiogram import Router, types
from utils.tg_auth import verify_init_data

router = Router()


@router.message(lambda m: m.web_app_data is not None)
async def webapp_data_handler(message: types.Message):
    raw = message.web_app_data.data

    if not verify_init_data(raw):
        await message.answer("Ошибка авторизации WebApp.")
        return

    await message.answer(f"WebApp прислал данные:\n{raw}")


def register_webapp_handlers(dp):
    dp.include_router(router)
