# handlers/start.py
from aiogram import Router, types
from aiogram.types import WebAppInfo, ReplyKeyboardMarkup, KeyboardButton
from config import WEBAPP_URL

router = Router()


@router.message(commands=["start"])
async def start_cmd(message: types.Message):
    kb = ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(
                    text="Открыть панель снабженца",
                    web_app=WebAppInfo(url=WEBAPP_URL)
                )
            ]
        ],
        resize_keyboard=True
    )

    await message.answer(
        "Привет! Нажми кнопку ниже, чтобы открыть WebApp.",
        reply_markup=kb
    )


def register_start_handlers(dp):
    dp.include_router(router)
