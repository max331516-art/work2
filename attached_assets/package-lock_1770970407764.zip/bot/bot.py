# bot.py
import asyncio
from aiogram import Bot, Dispatcher
from config import BOT_TOKEN
from handlers.start import register_start_handlers
from handlers.webapp import register_webapp_handlers

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()


def register_all(dp):
    register_start_handlers(dp)
    register_webapp_handlers(dp)


async def main():
    register_all(dp)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
