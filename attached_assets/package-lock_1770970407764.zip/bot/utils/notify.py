# utils/notify.py
import requests
from config import BOT_TOKEN

BASE_URL = f"https://api.telegram.org/bot{BOT_TOKEN}"


def send_message(chat_id: int, text: str):
    url = f"{BASE_URL}/sendMessage"
    requests.post(url, json={"chat_id": chat_id, "text": text})


def notify_status_change(user_id: int, request_id: int, new_status: str):
    text = f"Статус заявки #{request_id} изменён на: {new_status}"
    send_message(user_id, text)
