# config.py
BOT_TOKEN = "8151739438:AAGf3a_ZL5CiP-2OQaB91AYrU1F4K-XKb_k"
API_URL = "http://localhost:8000"  # FastAPI backend
WEBAPP_URL = "https://your-domain.com/webapp"  # URL React WebApp
