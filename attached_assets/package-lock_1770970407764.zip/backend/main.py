# main.py
from fastapi import FastAPI
from routers import requests as requests_router

app = FastAPI(
    title="Snabzhenec API",
    version="1.0.0"
)

app.include_router(requests_router.router)


@app.get("/")
def root():
    return {"status": "ok", "message": "Snabzhenec API running"}
