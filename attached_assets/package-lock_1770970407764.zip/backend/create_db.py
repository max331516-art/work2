# create_db.py
from sqlalchemy import create_engine
from models import Base

# пример строки подключения, поменяешь под себя:
# postgresql://user:password@localhost:5432/snabdb
DATABASE_URL = "postgresql://user:password@localhost:5432/snabdb"

engine = create_engine(DATABASE_URL)


def init_db():
    Base.metadata.create_all(bind=engine)


if __name__ == "__main__":
    init_db()
    print("✅ База и таблицы созданы")
