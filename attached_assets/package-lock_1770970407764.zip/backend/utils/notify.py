from schemas import RequestCreate, RequestAssign
from models import Request, RequestStatus

def notify_status_change(request_id: int, new_status: str):
    print(f"[NOTIFY] Request {request_id} changed status to {new_status}")
