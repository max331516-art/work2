# routers/requests.py
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import get_db
import crud
from schemas import RequestCreate, RequestOut, RequestUpdateStatus, RequestAssign
from models import RequestStatus

router = APIRouter(prefix="/requests", tags=["Requests"])



@router.post("/", response_model=RequestOut)
def create_request(
    data: RequestCreate,
    db: Session = Depends(get_db),
    user_id: int = 123  # TODO: заменить на реальный user_id из Telegram initData
):
    return crud.create_request(db, user_id, data)


@router.get("/", response_model=list[RequestOut])
def list_requests(
    db: Session = Depends(get_db),
    user_id: int = 123,
    role: str = "foreman"
):
    return crud.get_requests_for_user(db, user_id, role)


@router.patch("/{request_id}/status", response_model=RequestOut)
def update_status(
    request_id: int,
    data: RequestUpdateStatus,
    db: Session = Depends(get_db),
    user_id: int = 123
):
    return crud.update_request_status(db, request_id, user_id, data.new_status)


@router.patch("/{request_id}/assign", response_model=RequestOut)
def assign_request(
    request_id: int,
    data: RequestAssign,
    db: Session = Depends(get_db)
):
    return crud.assign_request(db, request_id, data)
