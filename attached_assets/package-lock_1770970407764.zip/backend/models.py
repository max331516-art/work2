# models.py
from datetime import datetime, date
from sqlalchemy import (
    Column, String, Integer, BigInteger, Boolean,
    DateTime, Date, Float, ForeignKey, Enum
)
from sqlalchemy.orm import declarative_base, relationship
import enum

Base = declarative_base()


class UserRole(str, enum.Enum):
    FOREMAN = "foreman"      # прораб
    SUPPLIER = "supplier"    # снабженец
    DRIVER = "driver"        # водитель
    OWNER = "owner"          # владелец/директор


class RequestStatus(str, enum.Enum):
    NEW = "NEW"              # новая
    WORK = "WORK"            # в работе
    ON_WAY = "ON_WAY"        # в пути
    DELIVERED = "DELIVERED"  # доставлено
    CLOSED = "CLOSED"        # закрыто
    OVERDUE = "OVERDUE"      # просрочено


class User(Base):
    __tablename__ = "users"

    id = Column(BigInteger, primary_key=True)  # Telegram ID
    username = Column(String, nullable=True)
    full_name = Column(String, nullable=True)
    role = Column(Enum(UserRole), nullable=False)
    phone = Column(String, nullable=True)

    # связи
    created_requests = relationship(
        "Request",
        foreign_keys="Request.creator_id",
        back_populates="creator",
    )
    supplied_requests = relationship(
        "Request",
        foreign_keys="Request.supplier_id",
        back_populates="supplier",
    )
    driven_requests = relationship(
        "Request",
        foreign_keys="Request.driver_id",
        back_populates="driver",
    )


class Object(Base):
    __tablename__ = "objects"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)   # Название объекта
    address = Column(String, nullable=True)
    is_active = Column(Boolean, default=True)

    requests = relationship("Request", back_populates="object")


class Material(Base):
    __tablename__ = "materials"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)   # "Цемент М500"
    unit = Column(String, nullable=False)   # "мешок", "кг", "шт"

    # опционально: можно потом связать с Request через отдельную таблицу


class Request(Base):
    __tablename__ = "requests"

    id = Column(Integer, primary_key=True, autoincrement=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    deadline_date = Column(Date, nullable=True)  # дата поставки

    object_id = Column(Integer, ForeignKey("objects.id"), nullable=True)
    creator_id = Column(BigInteger, ForeignKey("users.id"), nullable=False)
    supplier_id = Column(BigInteger, ForeignKey("users.id"), nullable=True)
    driver_id = Column(BigInteger, ForeignKey("users.id"), nullable=True)

    material_name = Column(String, nullable=False)  # текстом (MVP)
    quantity = Column(Float, nullable=False)
    comment = Column(String, nullable=True)

    status = Column(Enum(RequestStatus), default=RequestStatus.NEW, nullable=False)

    # связи
    object = relationship("Object", back_populates="requests")
    creator = relationship("User", foreign_keys=[creator_id], back_populates="created_requests")
    supplier = relationship("User", foreign_keys=[supplier_id], back_populates="supplied_requests")
    driver = relationship("User", foreign_keys=[driver_id], back_populates="driven_requests")

    history = relationship("RequestHistory", back_populates="request", cascade="all, delete-orphan")


class RequestHistory(Base):
    __tablename__ = "request_history"

    id = Column(Integer, primary_key=True, autoincrement=True)
    request_id = Column(Integer, ForeignKey("requests.id"), nullable=False)
    user_id = Column(BigInteger, ForeignKey("users.id"), nullable=False)

    action = Column(String, nullable=False)       # "STATUS_CHANGE", "ASSIGNED_DRIVER" и т.п.
    prev_status = Column(String, nullable=True)
    new_status = Column(String, nullable=True)

    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)

    request = relationship("Request", back_populates="history")
