# schemas.py
from pydantic import BaseModel
from datetime import date, datetime
from typing import Optional
from models import RequestStatus, UserRole


class RequestCreate(BaseModel):
    object_id: int
    material_name: str
    quantity: float
    deadline_date: Optional[date] = None
    comment: Optional[str] = None


class RequestUpdateStatus(BaseModel):
    new_status: RequestStatus


class RequestAssign(BaseModel):
    supplier_id: Optional[int] = None
    driver_id: Optional[int] = None


class RequestOut(BaseModel):
    id: int
    material_name: str
    quantity: float
    status: RequestStatus
    deadline_date: Optional[date]
    created_at: datetime

    class Config:
        orm_mode = True


class ObjectOut(BaseModel):
    id: int
    name: str
    address: Optional[str]

    class Config:
        orm_mode = True
