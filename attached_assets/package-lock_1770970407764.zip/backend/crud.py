# crud.py
from sqlalchemy.orm import Session
from models import Request, RequestHistory, RequestStatus
from schemas import RequestCreate, RequestAssign
from utils.notify import notify_status_change


def create_request(db: Session, creator_id: int, data: RequestCreate):
    req = Request(
        creator_id=creator_id,
        object_id=data.object_id,
        material_name=data.material_name,
        quantity=data.quantity,
        deadline_date=data.deadline_date,
        comment=data.comment,
    )
    db.add(req)
    db.commit()
    db.refresh(req)
    return req


def get_requests_for_user(db: Session, user_id: int, role: str):
    query = db.query(Request)

    if role == "foreman":
        query = query.filter(Request.creator_id == user_id)

    if role == "driver":
        query = query.filter(Request.driver_id == user_id)

    if role == "supplier":
        query = query.filter(Request.supplier_id == user_id)

    return query.order_by(Request.created_at.desc()).all()


def update_request_status(db: Session, request_id: int, user_id: int, new_status: RequestStatus):
    req = db.query(Request).filter(Request.id == request_id).first()
    if not req:
        return None

    history = RequestHistory(
        request_id=request_id,
        user_id=user_id,
        action="STATUS_CHANGE",
        prev_status=req.status.value if req.status else None,
        new_status=new_status.value,
    )

    req.status = new_status
    db.add(history)
    db.commit()
    db.refresh(req)

    # уведомляем создателя заявки
    try:
        notify_status_change(
            user_id=req.creator_id,
            request_id=req.id,
            new_status=new_status.value
        )
    except Exception:
        # чтобы из‑за падения уведомлений не падал API
        pass

    return req


def assign_request(db: Session, request_id: int, data: RequestAssign):
    req = db.query(Request).filter(Request.id == request_id).first()
    if not req:
        return None

    if data.supplier_id:
        req.supplier_id = data.supplier_id

    if data.driver_id:
        req.driver_id = data.driver_id

    db.commit()
    db.refresh(req)
    return req
