const API_URL = "http://localhost:8000";

export async function createRequest(data) {
  const response = await fetch(`${API_URL}/requests`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    throw new Error("Ошибка при создании заявки");
  }

  return response.json();
}

export async function getRequests(role, userId) {
  const response = await fetch(`${API_URL}/requests?role=${role}&user_id=${userId}`);

  if (!response.ok) {
    throw new Error("Ошибка при загрузке заявок");
  }

  return response.json();
}
