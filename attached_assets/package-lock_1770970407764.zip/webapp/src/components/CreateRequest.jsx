import React, { useState } from "react";
import { createRequest } from "../api";

export default function CreateRequest({ userId }) {
  const [objectId, setObjectId] = useState("");
  const [material, setMaterial] = useState("");
  const [quantity, setQuantity] = useState("");
  const [deadlineDate, setDeadlineDate] = useState("");
  const [comment, setComment] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);

    try {
      await createRequest({
        object_id: Number(objectId),
        material_name: material,
        quantity: Number(quantity),
        deadline_date: deadlineDate,
        comment: comment
      });

      alert("Заявка создана!");
      setObjectId("");
      setMaterial("");
      setQuantity("");
      setDeadlineDate("");
      setComment("");
    } catch (err) {
      alert("Ошибка при создании заявки");
    }

    setLoading(false);
  }

  return (
    <div className="card">
      <h2>Создать заявку</h2>

      <form onSubmit={handleSubmit}>
        <input
          type="number"
          placeholder="Объект (ID)"
          value={objectId}
          onChange={(e) => setObjectId(e.target.value)}
          required
        />

        <input
          type="text"
          placeholder="Материал"
          value={material}
          onChange={(e) => setMaterial(e.target.value)}
          required
        />

        <input
          type="number"
          placeholder="Количество"
          value={quantity}
          onChange={(e) => setQuantity(e.target.value)}
          required
        />

        <input
          type="date"
          value={deadlineDate}
          onChange={(e) => setDeadlineDate(e.target.value)}
          required
        />

        <textarea
          placeholder="Комментарий"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
        />

        <button type="submit" disabled={loading}>
          {loading ? "Создаём..." : "Создать заявку"}
        </button>
      </form>
    </div>
  );
}
