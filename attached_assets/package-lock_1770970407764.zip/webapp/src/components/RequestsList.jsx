import React, { useEffect, useState } from "react";
import { getRequests } from "../api";

export default function RequestsList({ userId, role }) {
  const [requests, setRequests] = useState([]);

  async function load() {
    try {
      const data = await getRequests(role, userId);
      setRequests(data);
    } catch (err) {
      console.error(err);
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="card">
      <h2>Мои заявки</h2>

      {requests.length === 0 && <p>Пока нет заявок</p>}

      {requests.map((req) => (
        <div key={req.id} className="request-item">
          <b>{req.material}</b> — {req.quantity} шт  
          <br />
          Дата: {req.delivery_date}
          <br />
          Статус: {req.status}
        </div>
      ))}
    </div>
  );
}
