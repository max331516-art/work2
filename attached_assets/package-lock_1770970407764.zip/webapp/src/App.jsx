// src/App.jsx
import React, { useEffect } from "react";
import { useTelegram } from "./hooks/useTelegram";
import CreateRequest from "./components/CreateRequest";
import RequestsList from "./components/RequestsList";
import "./App.css";

export default function App() {
  const { tg, user } = useTelegram();

  useEffect(() => {
    tg?.ready();
    tg?.expand();
  }, [tg]);

  const userId = user?.id || 0;
  const role = "foreman"; // пока жёстко, потом можно брать из БД

  return (
    <div style={{ fontFamily: "system-ui, sans-serif" }}>
      <h1 style={{ padding: 16 }}>Снабженец</h1>
      <CreateRequest userId={userId} />
      <RequestsList userId={userId} role={role} />
    </div>
  );
}
